#!/bin/sh
echo -e "Copying files to their correct destinations..."
echo -e "The system may ask you for sudo password in order to install Ricin."
sudo cp -r -f share/ /usr/share/
sudo cp -f bin/Ricin /usr/bin/Ricin
echo -e "Ricin static binary was installed!"
exit 0
